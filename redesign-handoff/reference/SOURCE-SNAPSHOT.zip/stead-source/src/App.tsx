import { Navigate, Route, Routes } from "react-router-dom";
import { BookPage } from "./pages/Book";
import { ExplorePage } from "./pages/Explore";
import { LandingPage } from "./pages/Landing";
import { ListingDetailPage } from "./pages/ListingDetail";
import { LoginPage } from "./pages/Login";
import { ListingMessageRedirect, MessagesPage, MessageThreadPage } from "./pages/Messages";
import { TripDetailPage } from "./pages/TripDetail";
import { TripsPage } from "./pages/Trips";
import { HostListingsPage } from "./pages/HostListings";
import { HostListingEditPage } from "./pages/HostListingEdit";
import { HostPayoutsPage } from "./pages/HostPayouts";
import { HostClaimsPage } from "./pages/HostClaims";
import { HostClaimDetailPage } from "./pages/HostClaimDetail";
import { PassportPage } from "./pages/Passport";
import { OpsPage } from "./pages/Ops";
import { ReviewPage } from "./pages/Review";

export function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/explore" element={<ExplorePage />} />
      <Route path="/listing/:id" element={<ListingDetailPage />} />
      <Route path="/book/:listingId" element={<BookPage />} />
      <Route path="/trips" element={<TripsPage />} />
      <Route path="/trips/:bookingId" element={<TripDetailPage />} />
      <Route path="/messages" element={<MessagesPage />} />
      <Route path="/messages/:listingId" element={<ListingMessageRedirect />} />
      <Route path="/messages/:listingId/:guestId" element={<MessageThreadPage />} />
      <Route path="/review/:bookingId" element={<ReviewPage />} />
      <Route path="/passport/:userId" element={<PassportPage />} />
      <Route path="/host/listings" element={<HostListingsPage />} />
      <Route path="/host/listings/:listingId" element={<HostListingEditPage />} />
      <Route path="/host/payouts" element={<HostPayoutsPage />} />
      <Route path="/host/claims" element={<HostClaimsPage />} />
      <Route path="/host/claims/:claimId" element={<HostClaimDetailPage />} />
      <Route path="/ops" element={<OpsPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="*" element={<Navigate to="/explore" replace />} />
    </Routes>
  );
}
